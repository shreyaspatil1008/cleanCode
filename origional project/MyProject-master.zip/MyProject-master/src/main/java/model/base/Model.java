package main.java.model.base;

import java.io.Serializable;

public interface Model extends Serializable{

}
